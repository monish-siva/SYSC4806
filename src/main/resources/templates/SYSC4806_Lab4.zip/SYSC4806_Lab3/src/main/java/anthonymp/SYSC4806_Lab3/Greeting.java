package anthonymp.SYSC4806_Lab3;

public record Greeting(long id, String content) {}

