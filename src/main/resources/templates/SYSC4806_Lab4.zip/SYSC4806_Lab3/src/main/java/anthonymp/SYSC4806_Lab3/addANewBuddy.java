package anthonymp.SYSC4806_Lab3;

//public record create(long id, String content, String content2) { }
public record addANewBuddy(long id, String content,String content2) {}