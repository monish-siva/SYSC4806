package anthonymp.SYSC4806_Lab3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sysc4806Lab3ApplicationTests {

	/*@Test
	void contextLoads() {
	}*/

}
